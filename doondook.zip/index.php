<?php get_header(); ?>
index
<?php get_footer() ?>